<?php   
the_content();
?>